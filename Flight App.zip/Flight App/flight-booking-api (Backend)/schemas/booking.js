const mongoose = require('mongoose');

const bookingSchema = new mongoose.Schema({
    flightId: {
        required: true,
        type: mongoose.Schema.Types.ObjectId
    },
    userId: {
        required: true,
        type: mongoose.Schema.Types.ObjectId
    },
    dateOfTravel: {
        required: true,
        type: String
    },
    seatsAvailable: {
        required: true,
        type: Number
    }
});

module.exports = mongoose.model('booking', bookingSchema)