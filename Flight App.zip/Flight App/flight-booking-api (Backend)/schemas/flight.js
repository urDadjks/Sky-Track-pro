const mongoose = require('mongoose');

const flightSchema = new mongoose.Schema({
    flightNumber: {
        required: true,
        type: String
    },
    airlineName: {
        required: true,
        type: String
    },
    source: {
        required: true,
        type: String
    },
    destination: {
        required: true,
        type: String
    },
    time: {
        required: true,
        type: String
    }
});

module.exports = mongoose.model('flight', flightSchema)