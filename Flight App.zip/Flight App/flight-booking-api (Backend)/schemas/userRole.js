const mongoose = require('mongoose');

const userRoleSchema = new mongoose.Schema({
    name: {
        required: true,
        type: String
    }
});

module.exports = mongoose.model('user-role', userRoleSchema)