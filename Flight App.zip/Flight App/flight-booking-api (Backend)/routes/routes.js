const express = require('express');

const { default: mongoose } = require('mongoose');

const User = require('../schemas/user');
const UserRole = require('../schemas/userRole');
const Flight = require('../schemas/flight');
const Booking = require('../schemas/booking');

const router = express.Router();

// Login method
router.post('/login', async (req, res) => {
    if (!isNullOrUndefined(req.body.username) && !isNullOrUndefined(req.body.password)) {
        try {
            const data = await User.find({ username: req.body.username, password: req.body.password });
            res.json(data);
        }
        catch (error) {
            res.status(500).json({ message: error.message });
        }
    }
    else {
        res.send('Invalid request');
    }
});

// Get All User Roles
router.get('/userRoles/getAll', async (req, res) => {
    try {
        const data = await UserRole.find();
        res.json(data)
    }
    catch (error) {
        res.status(500).json({ message: error.message })
    }
});

// Get User Role By Id
router.get('/getUserRoleById/:id', async (req, res) => {
    if (!isNullOrUndefined(req.params.id)) {
        try {
            const data = await UserRole.findById(req.params.id);
            res.json(data);
        }
        catch (error) {
            res.status(500).json({ message: error.message });
        }
    }
    else {
        res.send('Invalid request');
    }
});

// Get User Role By Name
router.get('/getUserRole/:userRole', async (req, res) => {
    if (!isNullOrUndefined(req.params.userRole)) {
        try {
            const data = await getUserRoleByName(req.params.userRole);
            res.json(data);
        }
        catch (error) {
            res.status(500).json({ message: error.message });
        }
    }
    else {
        res.send('Invalid request');
    }
});

// Get User By Id
router.get('/getUserById/:id', async (req, res) => {
    if (!isNullOrUndefined(req.params.id)) {
        try {
            const data = await User.findById(req.params.id);
            res.json(data);
        }
        catch (error) {
            res.status(500).json({ message: error.message });
        }
    }
    else {
        res.send('Invalid request');
    }
});

// Add User
router.post('/register', async (req, res) => {
    if (!isNullOrUndefined(req.body.firstName) && !isNullOrUndefined(req.body.lastName) && !isNullOrUndefined(req.body.username) && !isNullOrUndefined(req.body.password) && !isNullOrUndefined(req.body.userRole)) {
        try {
            const userRoleId = (await getUserRoleByName(req.body.userRole))[0]._id;
            const user = new User({
                firstName: req.body.firstName,
                lastName: req.body.lastName,
                username: req.body.username,
                password: req.body.password,
                userRoleId: userRoleId
            });

            const newUser = user.save();
            res.status(200).json(newUser);
        }
        catch (error) {
            res.status(500).json({ message: error.message });
        }
    }
    else {
        res.send('Invalid request');
    }
});

// Get All Flights
router.get('/flights/getAll', async (req, res) => {
    try {
        const data = await Flight.find();
        res.json(data)
    }
    catch (error) {
        res.status(500).json({ message: error.message })
    }
});

// Add Flight
router.post('/addFlight', async (req, res) => {
    if (!isNullOrUndefined(req.body.flightNumber) && !isNullOrUndefined(req.body.airlineName) && !isNullOrUndefined(req.body.time)) {
        try {
            const flight = new Flight({
                flightNumber: req.body.flightNumber,
                airlineName: req.body.airlineName,
                source: req.body.source,
                destination: req.body.destination,
                time: req.body.time
            });

            const newFlight = flight.save();
            res.status(200).json(newFlight);
        }
        catch (error) {
            res.status(500).json({ message: error.message });
        }
    }
    else {
        res.send('Invalid request');
    }
});

// Remove Flight
router.delete('/removeFlight/:id', async (req, res) => {
    if (!isNullOrUndefined(req.params.id)) {
        try {
            const id = req.params.id;
            const data = await Flight.findByIdAndDelete(id)
            res.send(`Flight ${data.flightNumber} has been removed..`);
        }
        catch (error) {
            res.status(400).json({ message: error.message });
        }
    }
    else {
        res.send('Invalid request');
    }
});

// Search Flights
router.get('/searchFlights', async (req, res) => {
    if (!isNullOrUndefined(req.query.source) && !isNullOrUndefined(req.query.destination) && !isNullOrUndefined(req.query.date) && !isNullOrUndefined(req.query.time)) {
        try {
            const data = await Flight.find({ source: req.query.source, destination: req.query.destination, time: req.query.time });
            const availableFlights = [];
            for (let count = 0; count < data.length; count++) {
                var allBookings = await Booking.find({ flightId: data[count]._id, dateOfTravel: req.query.date });
                if (allBookings.length > 0 && allBookings[0].seatsAvailable > 0) {
                    availableFlights.push(data[count]);
                }
                else if (allBookings.length === 0) {
                    availableFlights.push(data[count]);
                }
            }
            res.json(availableFlights);
        }
        catch (error) {
            res.status(500).json({ message: error.message });
        }
    }
    else {
        res.send('Invalid request');
    }
});

// Book Flight
router.post('/bookFlight', async (req, res) => {
    if (!isNullOrUndefined(req.body.flightNumber) && !isNullOrUndefined(req.body.userId) && !isNullOrUndefined(req.body.dateOfTravel)) {
        try {
            const flightId = (await getFlightByNumber(req.body.flightNumber))[0]._id;
            const availableSeats = await getAvailableSeatsByFlightAndDate(flightId, req.body.dateOfTravel);
            if (availableSeats <= 0) {
                res.send('No seats available on this flight!');
            }
            else {
                const booking = new Booking({
                    flightId: flightId,
                    userId: req.body.userId,
                    dateOfTravel: req.body.dateOfTravel,
                    seatsAvailable: availableSeats - 1
                });

                const newBooking = booking.save();
                res.status(200).json(newBooking);
            }
        }
        catch (error) {
            res.status(500).json({ message: error.message });
        }
    }
    else {
        res.send('Invalid request');
    }
});

// View Bookings By User
router.get('/viewBookings/:id', async (req, res) => {
    if (!isNullOrUndefined(req.params.id)) {
        try {
            const data = await Booking.find({ userId: req.params.id });
            res.json(data);
        }
        catch (error) {
            res.status(500).json({ message: error.message });
        }
    }
    else {
        res.send('Invalid request');
    }
});

// View Bookings With Filters
router.get('/viewBookings', async (req, res) => {
    if (!isNullOrUndefined(req.query.flightNumber) && !isNullOrUndefined(req.query.date)) {
        try {
            const flightId = (await getFlightByNumber(req.query.flightNumber))[0]._id;
            const data = await Booking.find({ flightId: flightId, dateOfTravel: req.query.date });
            res.json(data);
        }
        catch (error) {
            res.status(500).json({ message: error.message });
        }
    }
    else {
        res.send('Invalid request');
    }
});

// Private functions
function isNullOrUndefined(obj) {
    if (obj === null || obj === undefined || obj === "")
        return true;
    return false;
}

async function getUserRoleByName(userRole) {
    return await UserRole.find({ name: userRole });
}

async function getFlightByNumber(flightNumber) {
    return await Flight.find({ flightNumber: flightNumber });
}

async function getAvailableSeatsByFlightAndDate(flightId, dateOfTravel) {
    const bookings = await Booking.find({ flightId: flightId, dateOfTravel: dateOfTravel });
    if (bookings.length > 0) {
        return bookings[0].seatsAvailable;
    }
    else {
        return process.env.DEFAULT_SEATS_AVAILABLE;
    }
}

module.exports = router;